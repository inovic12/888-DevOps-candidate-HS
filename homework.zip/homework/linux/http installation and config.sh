html_dir=("/var/www/site1/html")
log_dir=("/var/www/site1/log")
sites_a_dir=("/etc/httpd/sites-available")
sites_e_dir=("/etc/httpd/sites-enabled")
yum install httpd -q -y
#yum install mod_ssl -q -y
firewall-cmd --permanent --zone=public --add-service=http
firewall-cmd --permanent --zone=public --add-service=https
firewall-cmd --reload
systemctl enable httpd

mkdir -p $html_dir
mkdir -p $log_dir
mkdir $sites_a_dir $sites_e_dir
chown -R $USER:$USER $html_dir
chmod -R 755 /var/www

echo "<html>
  <head>
    <title>Hello World</title>
  </head>
  <body>
    <p>Hello World</p>
  </body>
</html>" > $html_dir/index.html

echo "<VirtualHost *:80>
    ServerName site1
    ServerAlias site
    DocumentRoot /var/www/site1/html
    ErrorLog /var/www/site1/log/error.log
    CustomLog /var/www/site1/log/requests.log combined
</VirtualHost>" > $sites_a_dir/site1.conf

ln -s $sites_a_dir/site1.conf $sites_e_dir/site1.conf
setsebool -P httpd_unified 1
semanage fcontext -a -t httpd_log_t "$log_dir(/.*)?"
restorecon -R -v $log_dir

echo "IncludeOptional sites-enabled/*.conf" >> /etc/httpd/conf/httpd.conf
systemctl start httpd
