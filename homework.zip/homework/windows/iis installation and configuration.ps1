﻿install-WindowsFeature -name 'Web-Server' -IncludeManagementTools

New-Item -ItemType directory -Name 'site' -Path C:\inetpub\ -Force
Copy-Item $env:SystemRoot\system32\cmd.exe C:\inetpub\site\cmd.exe -Force

ConvertTo-Html -Title "Hello World!" -Body "<p>Hello World!</p><a href=""cmd.exe""> Download</a>" > C:\inetpub\site\index.html

New-Website -Name 'site' -Port 8080 -PhysicalPath 'C:\inetpub\site'

Restart-WebAppPool -Name DefaultAppPool


New-WebBinding 'site' -Protocol 'https' -Port 443

$cert = new-SelfSignedCertificate -dnsname "domain.local" -CertStoreLocation "Cert:\LocalMachine\My"
$binding=Get-WebBinding 'site'
$binding.AddSslCertificate($cert.GetCertHashString(),"my")