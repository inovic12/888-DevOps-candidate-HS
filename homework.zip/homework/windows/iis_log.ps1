﻿$log =@()

$columns =  'date time s-ip cs-method cs-uri-stem cs-uri-query s-port cs-username c-ip cs(User-Agent) cs(Referer) sc-status sc-substatus sc-win32-status time-taken' -replace ' ',''','''

$files = (Get-ChildItem 'C:\inetpub\logs\LogFiles\W3SVC2\u_ex*' -File | where name -like 'u_ex*' ).fullname
foreach($f in $files){

$log_content +=(Get-Content $f  | Where {$_ -NotLike '#*'}) -replace ' ',','
}

foreach($l in $log_content){
$log += $l | ConvertFrom-String -Delimiter ',' -PropertyNames 'date','time','s-ip','cs-method','cs-uri-stem','cs-uri-query','s-port','cs-username','c-ip','cs(User-Agent)','cs(Referer)','sc-status','sc-substatus','sc-win32-status','time-taken'

}

$log | select @{Name='date';expr={$_.date |get-date -Format 'yyyy-MM-dd'}}, time, s-ip, cs-uri-query, sc-status | Export-Csv "$env:USERPROFILE\desktop\iis_log.csv"





